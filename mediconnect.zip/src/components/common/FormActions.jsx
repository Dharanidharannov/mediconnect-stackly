import {
  Button,
  Box,
} from "@mui/material";

function FormActions({
  onBack,
  nextText,
  disabled,
}) {
  return (
   <Box
  sx={{
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
  }}
>
      {onBack && (
        <Button
          onClick={onBack}
          sx={{
            textTransform: "none",
            fontWeight: 600,
          }}
        >
          Go Back
        </Button>
      )}

      <Button
        type="submit"
        variant="contained"
        disabled={disabled}
        sx={{
          minWidth: "240px",
          height: "56px",
          borderRadius: "12px",
          textTransform: "none",
          fontWeight: 600,
          boxShadow: "none",
        }}
      >
        {nextText}
      </Button>
    </Box>
  );
}

export default FormActions;